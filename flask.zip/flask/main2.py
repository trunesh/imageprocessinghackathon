import keras
import tensorflow as tf
import cv2
import numpy as np
import os
import zipfile

'''

def get_curr_files():
	for r,d,f in os.walk('/home/trunesh/Downloads/flask/UPLOADS'):
		for fi in f:
			return
get_curr_files()
'''
def all_files_under(path):
    for cur_path, dirnames, filenames in os.walk(path):
        for filename in filenames:
            yield os.path.join(cur_path, filename)

latest_file = max(all_files_under('/home/trunesh/Downloads/flask/UPLOADS/'), key=os.path.getmtime)
with zipfile.ZipFile(latest_file, 'r') as zip_ref:
    zip_ref.extractall('/home/trunesh/Downloads/flask/data')