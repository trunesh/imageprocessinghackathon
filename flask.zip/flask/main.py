import os

import keras
import tensorflow as tf
import cv2
import numpy as np
import os
import zipfile

'''

def get_curr_files():
	for r,d,f in os.walk('/home/trunesh/Downloads/flask/UPLOADS'):
		for fi in f:
			return
get_curr_files()
'''

#import magic
import urllib.request
from app import app
from flask import Flask, flash, request, redirect, render_template, url_for
from werkzeug.utils import secure_filename
imgs=[]
lbls=[]
finald=dict()

ALLOWED_EXTENSIONS = set([ 'png', 'jpg', 'jpeg', 'zip'])

def allowed_file(filename):
	return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS
	
@app.route('/')
def upload_form():
	return render_template('upload.html')

@app.route('/data')
def data():
	return render_template("display.html",lenofimage=len(lbls),lbls=lbls,imgs=imgs)
@app.route('/', methods=['POST'])
def upload_file():
	if request.method == 'POST':
        # check if the post request has the file part
		file = request.files['file']
		if file.filename == '':
			flash('No file selected for uploading')
			return redirect(request.url)
		if file and allowed_file(file.filename):
			filename = secure_filename(file.filename)
			file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
			flash('File successfully uploaded')
			all_files_under()
			display()
			return redirect(url_for("data"))
		else:
			flash('Allowed file types are txt, pdf, png, jpg, jpeg, gif')
			return redirect(request.url)

def all_files_under():
	path='/home/trunesh/Downloads/flask/UPLOADS'
	paths=[]
	for cur_path, dirnames, filenames in os.walk(path):
		for filename in filenames:
			paths.append(os.path.join(cur_path, filename))
	latest_file = max(paths, key=os.path.getmtime)
	with zipfile.ZipFile(latest_file, 'r') as zip_ref:
		zip_ref.extractall('/home/trunesh/Downloads/flask/data')

def get_classlabel(class_code):
	labels = {2:'glacier', 4:'sea', 0:'buildings', 1:'forest', 5:'street', 3:'mountain'}
	return labels[class_code]

def display():
	model =tf.keras.models.load_model('/home/trunesh/Downloads/model.hdf5')

	model.compile(loss='binary_crossentropy',
              optimizer='rmsprop',
              metrics=['accuracy'])

	for r,d,f in os.walk('/home/trunesh/Downloads/flask/data'):
		for fi in f:
			tpath=os.path.join(r,fi)
			imgs.append(tpath)

	for path in imgs:
		img = cv2.imread(path)
		img = cv2.resize(img,(150,150))
		img = np.reshape(img,[1,150,150,3])
		classes = model.predict_classes(img)
		label=get_classlabel(classes[0])
		print(label+"-->"+path)


if __name__ == "__main__":
    app.run()